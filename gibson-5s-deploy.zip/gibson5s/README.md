# Gibson 5S Audit System

## Deploy to Vercel (Free — 5 minutes)

### Step 1 — Create a free Vercel account
Go to https://vercel.com and sign up free (use Google or GitHub).

### Step 2 — Install Vercel CLI (one time)
Open Terminal on your computer and run:
```
npm install -g vercel
```

### Step 3 — Deploy
In Terminal, navigate to this folder and run:
```
vercel
```
Follow the prompts — accept all defaults.

Your app will be live at a URL like:
**https://gibson-5s-audit.vercel.app**

---

## Install on Phone (After deploying)

### iPhone
1. Open the URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Tap **Add to Home Screen**
4. Tap **Add**
5. The Gibson 5S app icon appears on your home screen

### Android
1. Open the URL in **Chrome**
2. Tap the 3-dot menu
3. Tap **Add to Home Screen**
4. Tap **Add**

---

## Share with your team
Just send them the Vercel URL. They follow the same "Add to Home Screen" steps.

---

## Re-deploy after changes
If you update the code, run `vercel --prod` again from this folder.

---

## Local development (optional)
```
npm install
npm start
```
Opens at http://localhost:3000
