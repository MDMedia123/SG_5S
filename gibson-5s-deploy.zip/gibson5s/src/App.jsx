import { useState, useRef, useEffect } from "react";

// ── DESIGN TOKENS ─────────────────────────────────────────
const TEAL    = "#1B9BAA";
const SGREY   = "#4A4A4A";
const FONT    = "'Nunito','Segoe UI',sans-serif";
const MONO    = "'JetBrains Mono','Courier New',monospace";

const C = {
  bg:         "#1E2025",
  surface:    "#26292F",
  surfaceAlt: "#2D3038",
  border:     "#383C47",
  ink:        "#F1F4FA",
  inkMid:     "#A8B3C8",
  inkLight:   "#6B7899",
  teal:       TEAL,
  tealDk:     "#148A96",
  // 5S colours
  s1:"#EF4444", s1b:"rgba(239,68,68,0.14)",  s1g:"linear-gradient(135deg,#EF4444,#F87171)",
  s2:"#F59E0B", s2b:"rgba(245,158,11,0.14)", s2g:"linear-gradient(135deg,#F59E0B,#FCD34D)",
  s3:"#10B981", s3b:"rgba(16,185,129,0.14)", s3g:"linear-gradient(135deg,#10B981,#34D399)",
  s4:TEAL,      s4b:"rgba(27,155,170,0.14)", s4g:`linear-gradient(135deg,${TEAL},#22BDD0)`,
  s5:"#8B5CF6", s5b:"rgba(139,92,246,0.14)", s5g:"linear-gradient(135deg,#8B5CF6,#A78BFA)",
  // status
  open:    "#EF4444", openBg:    "rgba(239,68,68,0.14)",
  prog:    "#F59E0B", progBg:    "rgba(245,158,11,0.14)",
  closed:  "#10B981", closedBg:  "rgba(16,185,129,0.14)",
  shadow:  "0 2px 12px rgba(0,0,0,0.4)",
};

// ── TEAM ──────────────────────────────────────────────────
const USERS = [
  { id:"rajen",    name:"Rajen Padayachee",     dept:"Litho Print",          role:"Manager",    title:"Litho Print Manager",         initials:"RP", color:TEAL       },
  { id:"mark",     name:"Mark O'Brien",          dept:"Finishing",            role:"Manager",    title:"Finishing Manager",           initials:"MO", color:"#F59E0B"  },
  { id:"riaan",    name:"Riaan Roux",            dept:"Punching",             role:"Manager",    title:"Punching Manager",            initials:"RR", color:"#EF4444"  },
  { id:"sibusiso", name:"Sibusiso Ngubane",      dept:"Quality Assurance",    role:"Manager",    title:"QA Manager",                  initials:"SN", color:"#10B981"  },
  { id:"nishaal",  name:"Nishaal Ramnarun",      dept:"Raw Materials",        role:"Manager",    title:"Raw Materials Controller",    initials:"NR", color:"#8B5CF6"  },
  { id:"desigran", name:"Desigran Moodley",      dept:"Repro",                role:"Supervisor", title:"Repro Supervisor",            initials:"DM", color:"#F59E0B"  },
  { id:"manoj",    name:"Manoj Singh",           dept:"Corrugating",          role:"Supervisor", title:"Corrugating Supervisor",      initials:"MS", color:TEAL       },
  { id:"yougash",  name:"Yougashree Padayachee", dept:"Logistics",            role:"Manager",    title:"Logistics Manager",          initials:"YP", color:"#EC4899"  },
  { id:"michael",  name:"Michael Downes",        dept:"Innovation & Quality", role:"Auditor",    title:"Innovation/Quality Manager",  initials:"MD", color:TEAL       },
  { id:"clifford", name:"Clifford Barnes",        dept:"Quality Assurance",    role:"Auditor",    title:"QA Controller",               initials:"CB", color:"#6B7899"  },
  { id:"richard",  name:"Richard Downes",         dept:"Executive",            role:"Admin",      title:"Managing Director",           initials:"RD", color:SGREY      },
  { id:"jason",    name:"Jason Staats",           dept:"Finance",              role:"Admin",      title:"Financial Director",          initials:"JS", color:SGREY      },
];

const DEPARTMENTS = [
  "Litho Print","Finishing","Punching","Quality Assurance","Raw Materials",
  "Repro","Corrugating","Logistics","Innovation & Quality","Warehouse","Dispatch","Maintenance",
];

// ── 5S CATEGORIES ─────────────────────────────────────────
const SCATS = [
  { key:"sort",    short:"S1", label:"SORT",         jp:"Seiri",   color:"#EF4444", bg:"rgba(239,68,68,0.14)",  grad:"linear-gradient(135deg,#EF4444,#F87171)", icon:"⊗",
    questions:[
      { q:"Only required materials, tools & WIP are present at workstation",      ref:"GIB-SOP-001 §3.1" },
      { q:"Red-tagged items identified and removed or quarantined this period",    ref:"GIB-SOP-001 §3.2" },
      { q:"No obsolete dies, plates or tooling found in work area",               ref:"GIB-SOP-001 §3.3" },
      { q:"WIP quantity does not exceed the defined batch limit",                  ref:"GIB-SOP-001 §3.4" },
      { q:"Walkways and emergency routes clear of all materials and equipment",    ref:"GIB-SOP-001 §3.5" },
    ]},
  { key:"set",     short:"S2", label:"SET IN ORDER", jp:"Seiton",  color:"#F59E0B", bg:"rgba(245,158,11,0.14)", grad:"linear-gradient(135deg,#F59E0B,#FCD34D)", icon:"⊞",
    questions:[
      { q:"All tools and equipment in designated, labelled storage positions",     ref:"GIB-SOP-002 §3.1" },
      { q:"Floor markings, shadow boards and rack labels visible and undamaged",   ref:"GIB-SOP-002 §3.2" },
      { q:"FIFO system in place and actively followed",                            ref:"GIB-SOP-002 §3.3" },
      { q:"Pallets stored only in authorised zones per site layout GIB-FL-003",   ref:"GIB-SOP-002 §3.4" },
      { q:"Materials returned to correct location after use without prompting",    ref:"GIB-SOP-002 §3.5" },
    ]},
  { key:"shine",   short:"S3", label:"SHINE",        jp:"Seiso",   color:"#10B981", bg:"rgba(16,185,129,0.14)", grad:"linear-gradient(135deg,#10B981,#34D399)", icon:"◎",
    questions:[
      { q:"Work surfaces, benches and floors clean and free of debris and ink",    ref:"GIB-SOP-003 §3.1" },
      { q:"Machinery wiped down and cleaned at shift end per maintenance log",     ref:"GIB-SOP-003 §3.2" },
      { q:"Waste bins not overflowing and emptied on schedule",                    ref:"GIB-SOP-003 §3.3" },
      { q:"Cleaning schedule posted, visible, and all sign-off boxes completed",   ref:"GIB-SOP-003 §3.4" },
      { q:"Drains, ducts and ventilation points clear and inspected this month",   ref:"GIB-SOP-003 §3.5" },
    ]},
  { key:"std",     short:"S4", label:"STANDARDISE",  jp:"Seiketsu",color:TEAL,      bg:"rgba(27,155,170,0.14)", grad:`linear-gradient(135deg,${TEAL},#22BDD0)`,  icon:"⊡",
    questions:[
      { q:"5S standards, visual controls and SOPs posted at point of use",         ref:"GIB-SOP-004 §3.1" },
      { q:"All stock units carry correct GIB-LAB-001 product ID and batch labels", ref:"GIB-SOP-004 §3.2" },
      { q:"Colour-coding for materials, tools and hazard zones consistently applied",ref:"GIB-SOP-004 §3.3"},
      { q:"Previous audit corrective actions signed off and closed",               ref:"GIB-SOP-004 §3.4" },
      { q:"Team aware of 5S responsibilities and visual standards",                 ref:"GIB-SOP-004 §3.5" },
    ]},
  { key:"sustain", short:"S5", label:"SUSTAIN",      jp:"Shitsuke",color:"#8B5CF6", bg:"rgba(139,92,246,0.14)", grad:"linear-gradient(135deg,#8B5CF6,#A78BFA)", icon:"⊕",
    questions:[
      { q:"5S score maintained or improved vs previous month audit",               ref:"GIB-SOP-005 §3.1" },
      { q:"Team completed 5S awareness training within the last 6 months",         ref:"GIB-SOP-005 §3.2" },
      { q:"Near misses and housekeeping issues logged promptly",                    ref:"GIB-SOP-005 §3.3" },
      { q:"At least one improvement suggestion submitted by team this month",       ref:"GIB-SOP-005 §3.4" },
      { q:"Management walkround conducted and signed off this period",              ref:"GIB-SOP-005 §3.5" },
    ]},
];

// ── STANDARDS LIBRARY ─────────────────────────────────────
const STDS = [
  { code:"GIB-HSE-001", title:"Emergency Egress & Fire Route Clearance",    type:"Safety Rule",       scat:"set",     status:"live", scope:"All departments",                   weights:{safety:30,product:5, sop:20,area:15}, dueDays:1  },
  { code:"GIB-HSE-002", title:"Hazardous Waste Container Labelling",         type:"Safety Rule",       scat:"shine",   status:"live", scope:"Litho Print, Repro, Corrugating",   weights:{safety:28,product:18,sop:18,area:12}, dueDays:2  },
  { code:"GIB-HSE-003", title:"Pallet Storage Zone Compliance",              type:"Safety Rule",       scat:"set",     status:"live", scope:"All departments",                   weights:{safety:25,product:10,sop:15,area:12}, dueDays:4  },
  { code:"GIB-HSE-004", title:"Machine Guarding & Barrier Integrity",        type:"Safety Rule",       scat:"std",     status:"live", scope:"Punching, Finishing, Corrugating",   weights:{safety:30,product:8, sop:22,area:18}, dueDays:1  },
  { code:"GIB-SOP-001", title:"Sort & Red Tag Procedure",                    type:"SOP",               scat:"sort",    status:"live", scope:"All departments",                   weights:{safety:8, product:15,sop:12,area:8 }, dueDays:7  },
  { code:"GIB-SOP-002", title:"Set In Order — Location & Labelling",         type:"SOP",               scat:"set",     status:"live", scope:"All departments",                   weights:{safety:10,product:18,sop:14,area:10}, dueDays:5  },
  { code:"GIB-SOP-003", title:"Shine — Cleaning & Inspection Schedule",      type:"SOP",               scat:"shine",   status:"live", scope:"All departments",                   weights:{safety:12,product:20,sop:12,area:8 }, dueDays:5  },
  { code:"GIB-SOP-004", title:"Standardise — Visual Controls & SOP Display", type:"SOP",               scat:"std",     status:"live", scope:"All departments",                   weights:{safety:8, product:22,sop:15,area:10}, dueDays:5  },
  { code:"GIB-SOP-005", title:"Sustain — Audit & Training Compliance",       type:"SOP",               scat:"sustain", status:"live", scope:"All departments",                   weights:{safety:5, product:10,sop:10,area:8 }, dueDays:14 },
  { code:"GIB-QMS-001", title:"Product Label & Batch Traceability",          type:"GMP Rule",          scat:"std",     status:"live", scope:"Raw Materials, Warehouse, Logistics",weights:{safety:5, product:30,sop:18,area:15}, dueDays:2  },
  { code:"GIB-QMS-002", title:"Ink & Chemical Storage Segregation",          type:"GMP Rule",          scat:"shine",   status:"live", scope:"Litho Print, Repro",                weights:{safety:22,product:20,sop:16,area:14}, dueDays:2  },
  { code:"GIB-VIS-001", title:"Floor Marking & Zone Colour Code Standard",   type:"Visual Agreement",  scat:"set",     status:"live", scope:"All departments",                   weights:{safety:15,product:12,sop:10,area:10}, dueDays:7  },
  { code:"GIB-WI-001",  title:"Shift End Cleaning & Machine Wipe-Down",      type:"Work Instruction",  scat:"shine",   status:"live", scope:"All production departments",         weights:{safety:10,product:18,sop:12,area:10}, dueDays:1  },
  { code:"GIB-WI-002",  title:"Waste Bin Rotation & Overflow Prevention",    type:"Work Instruction",  scat:"shine",   status:"live", scope:"All departments",                   weights:{safety:12,product:8, sop:8, area:6 }, dueDays:1  },
  { code:"GIB-OPL-001", title:"FIFO — First In First Out Visual Check",      type:"One Point Lesson",  scat:"set",     status:"live", scope:"Raw Materials, Warehouse",           weights:{safety:3, product:20,sop:10,area:10}, dueDays:3  },
];

const SEVERITY_BANDS = [
  { min:0,  max:20,  label:"Observation",  color:"#6B7899", priority:"LOG",      dueMult:2.0 },
  { min:21, max:40,  label:"Minor NCR",    color:TEAL,      priority:"LOW",      dueMult:1.5 },
  { min:41, max:60,  label:"Moderate NCR", color:"#F59E0B", priority:"MEDIUM",   dueMult:1.0 },
  { min:61, max:80,  label:"Major NCR",    color:"#EF4444", priority:"HIGH",     dueMult:0.5 },
  { min:81, max:100, label:"Critical NCR", color:"#9333EA", priority:"CRITICAL", dueMult:0.25},
];

function getSeverityBand(score) {
  return SEVERITY_BANDS.find(b => score >= b.min && score <= b.max) || SEVERITY_BANDS[0];
}
function computeScore(std, repeatCount, visualCond) {
  return Math.min(100,
    Math.min(std.weights.safety,30) +
    Math.min(std.weights.product,25) +
    Math.min(repeatCount*5,15) +
    Math.min(std.weights.sop,15) +
    Math.min(std.weights.area,10) +
    Math.round((visualCond/4)*5)
  );
}

// ── SCORING ───────────────────────────────────────────────
const catScore = (answers, catKey) => {
  const cat = SCATS.find(c => c.key === catKey);
  if (!cat) return null;
  let total = 0, answered = 0;
  cat.questions.forEach((_, i) => {
    const v = answers[`${catKey}_${i}`];
    if (v !== undefined) { total += v; answered++; }
  });
  return answered === 0 ? null : Math.round((total / (answered * 4)) * 100);
};
const deptScore = (answers) => {
  const scores = SCATS.map(c => catScore(answers, c.key)).filter(v => v !== null);
  return scores.length === 0 ? null : Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
};
const scoreColor = v => v >= 80 ? C.closed : v >= 60 ? C.prog : C.open;
const scoreLabel = v => v >= 80 ? "COMPLIANT" : v >= 60 ? "DEVELOPING" : "NEEDS ACTION";

// ── SEED DATA ─────────────────────────────────────────────
const SEED_ISSUES = [
  {
    id:"NC-001", dept:"Punching", manager:"Riaan Roux", mgrColor:"#EF4444", mgrInit:"RR",
    desc:"Pallet blocking fire extinguisher access near press No.3.",
    scat:SCATS[1], status:"OPEN", raisedBy:"Michael Downes", raisedAt:"2026-05-04 08:22",
    ncType:"Major NCR", severityScore:68, severityBand:SEVERITY_BANDS[3],
    governingStd:STDS[0], hasGoverningStandard:true, priority:"HIGH", dueDate:"2026-05-05",
    aiNote:"Nonconformance recorded under SET IN ORDER (Seiton). Pallet placement adjacent to press No.3 breaches GIB-HSE-001 emergency egress standard. Corrective action mandatory within 4 hours.",
    photo:null, closeEvidence:null,
    timeline:[
      { time:"2026-05-04 08:22", actor:"Michael Downes",    action:"Finding raised",                                       type:"raise" },
      { time:"2026-05-04 08:22", actor:"AI Engine L2",      action:"Classified: Pallet — blocking emergency access",       type:"ai"    },
      { time:"2026-05-04 08:22", actor:"Standards Engine L3",action:"GIB-HSE-001 verified (live)",                         type:"ai"    },
      { time:"2026-05-04 08:22", actor:"Scoring Engine L4", action:"Score: 68/100 → Major NCR · Riaan Roux notified",      type:"ai"    },
    ]
  },
  {
    id:"NC-002", dept:"Raw Materials", manager:"Nishaal Ramnarun", mgrColor:"#8B5CF6", mgrInit:"NR",
    desc:"Unlabelled stock boxes — batch traceability compromised.",
    scat:SCATS[3], status:"IN PROGRESS", raisedBy:"Clifford Barnes", raisedAt:"2026-05-03 14:05",
    ncType:"Moderate NCR", severityScore:48, severityBand:SEVERITY_BANDS[2],
    governingStd:STDS[9], hasGoverningStandard:true, priority:"MEDIUM", dueDate:"2026-05-05",
    aiNote:"Nonconformance under STANDARDISE (Seiketsu). GIB-QMS-001 batch traceability requirement breached. Labels must be applied within 48 hours.",
    photo:null, closeEvidence:null,
    timeline:[
      { time:"2026-05-03 14:05", actor:"Clifford Barnes",   action:"Finding raised · Photo attached",                      type:"raise" },
      { time:"2026-05-03 14:05", actor:"AI Engine L2",      action:"Classified: Stock boxes — missing ID labels",          type:"ai"    },
      { time:"2026-05-03 14:05", actor:"Standards Engine L3",action:"GIB-QMS-001 verified (live)",                         type:"ai"    },
      { time:"2026-05-03 14:05", actor:"Scoring Engine L4", action:"Score: 48/100 → Moderate NCR · Nishaal notified",      type:"ai"    },
      { time:"2026-05-03 16:30", actor:"Nishaal Ramnarun",  action:"Acknowledged — labels being sourced",                  type:"update"},
    ]
  },
  {
    id:"NC-003", dept:"Litho Print", manager:"Rajen Padayachee", mgrColor:TEAL, mgrInit:"RP",
    desc:"Ink waste containers not labelled — regulatory breach risk.",
    scat:SCATS[2], status:"CLOSED", raisedBy:"Michael Downes", raisedAt:"2026-05-01 10:45",
    ncType:"Major NCR", severityScore:72, severityBand:SEVERITY_BANDS[3],
    governingStd:STDS[1], hasGoverningStandard:true, priority:"HIGH", dueDate:"2026-05-03",
    aiNote:"Nonconformance under SHINE (Seiso). GIB-HSE-002 breached. All containers must be labelled within 2 hours.",
    photo:null,
    closeEvidence:{ note:"All containers labelled, waste register updated, team briefed.", photo:null, doc:"waste-register-may2026.pdf" },
    timeline:[
      { time:"2026-05-01 10:45", actor:"Michael Downes",    action:"Finding raised",                                       type:"raise" },
      { time:"2026-05-01 10:45", actor:"AI Engine L2",      action:"Classified: Ink containers — unlabelled hazardous waste",type:"ai"  },
      { time:"2026-05-01 10:45", actor:"Standards Engine L3",action:"GIB-HSE-002 verified (live)",                         type:"ai"    },
      { time:"2026-05-01 10:45", actor:"Scoring Engine L4", action:"Score: 72/100 → Major NCR · Rajen notified",           type:"ai"    },
      { time:"2026-05-01 11:30", actor:"Rajen Padayachee",  action:"Acknowledged",                                         type:"update"},
      { time:"2026-05-01 14:00", actor:"Rajen Padayachee",  action:"Closed · Doc: waste-register-may2026.pdf",             type:"update"},
    ]
  },
];

const SEED_AUDITS = {
  "Punching":     { sort_0:3,sort_1:2,sort_2:3,sort_3:3,sort_4:2, set_0:2,set_1:3,set_2:2,set_3:1,set_4:3, shine_0:3,shine_1:3,shine_2:2,shine_3:3,shine_4:2, std_0:2,std_1:3,std_2:3,std_3:2,std_4:3, sustain_0:3,sustain_1:2,sustain_2:3,sustain_3:2,sustain_4:3 },
  "Litho Print":  { sort_0:4,sort_1:3,sort_2:4,sort_3:3,sort_4:4, set_0:3,set_1:4,set_2:3,set_3:3,set_4:4, shine_0:3,shine_1:4,shine_2:3,shine_3:4,shine_4:3, std_0:4,std_1:3,std_2:3,std_3:4,std_4:3, sustain_0:3,sustain_1:4,sustain_2:3,sustain_3:3,sustain_4:4 },
  "Raw Materials":{ sort_0:2,sort_1:2,sort_2:3,sort_3:2,sort_4:3, set_0:3,set_1:2,set_2:3,set_3:2,set_4:2, shine_0:2,shine_1:2,shine_2:3,shine_3:2,shine_4:1, std_0:1,std_1:1,std_2:2,std_3:2,std_4:2, sustain_0:2,sustain_1:2,sustain_2:1,sustain_3:2,sustain_4:2 },
};

// ── AI CALLS ──────────────────────────────────────────────
async function callAI(desc, catLabel, dept, manager) {
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({
        model:"claude-sonnet-4-20250514", max_tokens:600,
        messages:[{ role:"user", content:
          `You are the 5S Compliance Authority for Gibson Packaging. Write a formal compliance notification (3 sentences) for this finding:
Department: ${dept} | Manager: ${manager} | 5S Category: ${catLabel} | Finding: "${desc}"
Include: 5S category breach with Japanese name, a Gibson standard reference (e.g. GIB-HSE-001), corrective action and deadline. Direct, no bullet points.`
        }]
      })
    });
    const d = await res.json();
    return d.content?.[0]?.text || "";
  } catch { return ""; }
}

async function classifyFinding(desc, dept, imgB64) {
  const stdList = STDS.map(s => `${s.code}|${s.title}|${s.scat}|${s.status}`).join("\n");
  const prompt = `You are the AI Compliance Engine for Gibson Packaging.
Finding: "${desc}" in department: ${dept || "unknown"}
Standards library:\n${stdList}

Reply ONLY with valid JSON (no markdown):
{"object":"1-4 words","condition":"5-10 words","riskCategory":"Safety|Quality|Housekeeping|Compliance","scat":"sort|set|shine|std|sustain","scatReason":"one sentence","primaryStandard":"GIB-HSE-001","standardStatus":"live|draft|none","hasGoverningStandard":true,"proposedStandardTitle":"","visualConditionScore":2,"immediateAction":"one sentence","confidence":"high|medium|low"}`;

  try {
    const content = imgB64
      ? [{ type:"image", source:{ type:"base64", media_type:"image/jpeg", data: imgB64.replace(/^data:image\/\w+;base64,/,"") }}, { type:"text", text:prompt }]
      : [{ type:"text", text:prompt }];
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:600, messages:[{ role:"user", content }] })
    });
    const d = await res.json();
    const text = (d.content?.[0]?.text || "").trim();
    return JSON.parse(text);
  } catch { return null; }
}

// ── STYLE INJECTION ───────────────────────────────────────
function injectStyles() {
  if (document.getElementById("g5s")) return;
  const el = document.createElement("style");
  el.id = "g5s";
  el.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;700&display=swap');
    *{box-sizing:border-box} ::-webkit-scrollbar{display:none}
    @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes slideUp{from{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}
    @keyframes spin{to{transform:rotate(360deg)}}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
    @keyframes popIn{from{opacity:0;transform:scale(0.92)}to{opacity:1;transform:scale(1)}}
    .card{animation:fadeUp 0.3s ease both}
    .card:nth-child(2){animation-delay:.06s}
    .card:nth-child(3){animation-delay:.12s}
    .card:nth-child(4){animation-delay:.18s}
    button:active{transform:scale(0.97)}
  `;
  document.head.appendChild(el);
}

// ─────────────────────────────────────────────────────────
// SHARED UI COMPONENTS  (defined first so all views can use them)
// ─────────────────────────────────────────────────────────

function Shell({ children, toast }) {
  return (
    <div style={{ background:C.bg, minHeight:"100vh", display:"flex", justifyContent:"center" }}>
      <div style={{ width:"100%", maxWidth:480, background:C.bg, minHeight:"100vh",
        paddingBottom:88, fontFamily:FONT, position:"relative" }}>
        {children}
        {toast && (
          <div style={{ position:"fixed", bottom:96, left:"50%", transform:"translateX(-50%)",
            background:`linear-gradient(135deg,${C.closed},#34D399)`, color:"#fff",
            padding:"10px 22px", borderRadius:100, fontSize:13, fontWeight:800,
            letterSpacing:1, boxShadow:`0 6px 24px ${C.closed}44`,
            whiteSpace:"nowrap", zIndex:999, animation:"popIn 0.2s ease" }}>
            {toast}
          </div>
        )}
      </div>
    </div>
  );
}

function Av({ txt, color, size=36 }) {
  return (
    <div style={{ width:size, height:size, borderRadius:"50%",
      background:`${color}22`, border:`2px solid ${color}55`,
      display:"flex", alignItems:"center", justifyContent:"center",
      fontSize:size*0.33, fontWeight:900, color, flexShrink:0, fontFamily:MONO }}>
      {txt}
    </div>
  );
}

function SHead({ label }) {
  return (
    <div style={{ padding:"16px 16px 8px", fontSize:10,
      color:C.inkLight, letterSpacing:3, fontWeight:800 }}>
      {label}
    </div>
  );
}

function FLabel({ text }) {
  return (
    <div style={{ fontSize:10, color:C.inkLight, letterSpacing:3,
      fontWeight:800, marginBottom:6, marginTop:14 }}>
      {text}
    </div>
  );
}

// Shared style snippets
const sx = {
  backBtnW:{ background:"rgba(255,255,255,0.2)", border:"1.5px solid rgba(255,255,255,0.35)",
    borderRadius:8, color:"#fff", padding:"6px 12px", fontSize:12, fontWeight:700,
    cursor:"pointer", fontFamily:FONT },
  textarea:{ width:"100%", background:C.surfaceAlt, border:`1.5px solid ${C.border}`,
    borderRadius:10, color:C.ink, padding:"12px", fontSize:13, fontFamily:FONT, resize:"none" },
  select:{ width:"100%", background:C.surfaceAlt, border:`1.5px solid ${C.border}`,
    borderRadius:10, color:C.ink, padding:"12px", fontSize:13, fontFamily:FONT },
  ghostBtn:{ flex:1, padding:"12px", background:C.surface, border:`1.5px solid ${C.border}`,
    borderRadius:10, color:C.inkMid, fontSize:13, fontWeight:700, fontFamily:FONT, cursor:"pointer" },
  solidBtn:{ flex:1, padding:"12px", border:"none", borderRadius:10, color:"#fff",
    fontSize:13, fontWeight:800, fontFamily:FONT, cursor:"pointer" },
};

// ─────────────────────────────────────────────────────────
// LOGIN SCREEN
// ─────────────────────────────────────────────────────────

function LoginScreen({ onLogin }) {
  const [sel, setSel] = useState("");
  const user = USERS.find(u => u.id === sel);

  return (
    <div style={{ background:"#1C1E23", minHeight:"100vh", display:"flex",
      flexDirection:"column", alignItems:"center", justifyContent:"center",
      padding:"24px 20px", position:"relative", overflow:"hidden", fontFamily:FONT }}>

      <div style={{ position:"absolute", top:0, left:0, right:0, height:5,
        background:`linear-gradient(90deg,${SGREY},${TEAL},${SGREY})`, zIndex:10 }}/>

      {/* Watermark */}
      <div style={{ position:"absolute", top:"50%", left:"50%",
        transform:"translate(-50%,-55%)", width:340, height:340,
        opacity:0.04, pointerEvents:"none", zIndex:0 }}>
        <svg viewBox="0 0 200 220" width="100%" height="100%">
          <text x="5" y="160" fontSize="180" fontWeight="900"
            fontFamily="Arial Black,sans-serif" fill={TEAL}>S</text>
          <text x="90" y="215" fontSize="140" fontWeight="900"
            fontFamily="Arial Black,sans-serif" fill={SGREY}>G</text>
        </svg>
      </div>

      <div style={{ position:"absolute", bottom:-80, right:-60, width:280, height:280,
        borderRadius:"50%", background:`radial-gradient(circle,${TEAL}14 0%,transparent 70%)`,
        pointerEvents:"none", zIndex:0 }}/>

      <div style={{ width:"100%", maxWidth:400, position:"relative",
        zIndex:2, animation:"slideUp 0.4s ease" }}>

        <div style={{ textAlign:"center", marginBottom:26 }}>
          <div style={{ width:90, height:90, borderRadius:22, background:"#26292F",
            border:`2px solid ${TEAL}44`, margin:"0 auto 16px",
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:"0 8px 32px rgba(0,0,0,0.6)" }}>
            <svg viewBox="0 0 100 120" width="60" height="60">
              <text x="2" y="72" fontSize="85" fontWeight="900"
                fontFamily="Arial Black,sans-serif" fill={SGREY}>S</text>
              <text x="34" y="114" fontSize="70" fontWeight="900"
                fontFamily="Arial Black,sans-serif" fill={TEAL}>G</text>
            </svg>
          </div>
          <div style={{ fontSize:11, color:TEAL, letterSpacing:6, fontWeight:900, marginBottom:6 }}>
            SHAVE &amp; GIBSON
          </div>
          <div style={{ fontSize:21, fontWeight:900, color:"#F1F4FA", letterSpacing:2 }}>
            5S AUDIT SYSTEM
          </div>
          <div style={{ fontSize:10, color:"#5A6170", letterSpacing:3, marginTop:6 }}>
            GIBSON PACKAGING · COMPLIANCE ENGINE
          </div>
        </div>

        <div style={{ background:"#26292F", borderRadius:18, padding:"24px 22px",
          border:"1px solid #383C47", boxShadow:"0 20px 60px rgba(0,0,0,0.6)" }}>

          <div style={{ fontSize:11, fontWeight:800, color:"#7A8499",
            letterSpacing:3, marginBottom:12 }}>SELECT YOUR NAME</div>

          <select style={{ width:"100%", padding:"12px", border:`2px solid ${sel?TEAL:"#383C47"}`,
            borderRadius:12, fontSize:14, fontFamily:FONT,
            color:sel?"#F1F4FA":"#5A6170", background:"#2D3038",
            marginBottom:14, outline:"none" }}
            value={sel} onChange={e => setSel(e.target.value)}>
            <option value="" style={{ color:"#5A6170", background:"#2D3038" }}>— Who are you? —</option>
            <optgroup label="Managers & Supervisors">
              {USERS.filter(u => u.role==="Manager"||u.role==="Supervisor").map(u => (
                <option key={u.id} value={u.id} style={{ color:"#F1F4FA", background:"#2D3038" }}>
                  {u.name} — {u.title}
                </option>
              ))}
            </optgroup>
            <optgroup label="Quality & Auditors">
              {USERS.filter(u => u.role==="Auditor").map(u => (
                <option key={u.id} value={u.id} style={{ color:"#F1F4FA", background:"#2D3038" }}>
                  {u.name} — {u.title}
                </option>
              ))}
            </optgroup>
            <optgroup label="Executive">
              {USERS.filter(u => u.role==="Admin").map(u => (
                <option key={u.id} value={u.id} style={{ color:"#F1F4FA", background:"#2D3038" }}>
                  {u.name} — {u.title}
                </option>
              ))}
            </optgroup>
          </select>

          {user && (
            <div style={{ background:`${user.color}18`, border:`1.5px solid ${user.color}44`,
              borderRadius:12, padding:"11px 13px", marginBottom:16,
              display:"flex", alignItems:"center", gap:12, animation:"fadeUp 0.2s ease" }}>
              <Av txt={user.initials} color={user.color} size={44}/>
              <div>
                <div style={{ fontSize:14, fontWeight:800, color:"#F1F4FA" }}>{user.name}</div>
                <div style={{ fontSize:11, color:user.color, fontWeight:700, marginTop:2 }}>{user.title}</div>
                <div style={{ fontSize:10, color:"#5A6170", marginTop:2 }}>{user.dept}</div>
              </div>
            </div>
          )}

          <button style={{ width:"100%", padding:"13px",
            background:sel?`linear-gradient(135deg,${TEAL},${C.tealDk})`:"#383C47",
            border:"none", borderRadius:12, color:sel?"#fff":"#5A6170",
            fontSize:14, fontWeight:800, letterSpacing:1, fontFamily:FONT,
            cursor:sel?"pointer":"default",
            boxShadow:sel?`0 6px 24px ${TEAL}44`:"none" }}
            onClick={() => { if (user) onLogin(user); }} disabled={!sel}>
            {sel ? `Sign In as ${user?.name.split(" ")[0]} →` : "Select your name above"}
          </button>
        </div>

        <div style={{ textAlign:"center", marginTop:18, fontSize:9,
          color:"#2C2F38", letterSpacing:3 }}>
          INTERNAL USE ONLY · GIBSON PACKAGING
        </div>
      </div>

      <div style={{ position:"absolute", bottom:0, left:0, right:0, height:4,
        background:`linear-gradient(90deg,${SGREY},${TEAL},${SGREY})`, zIndex:10 }}/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────

function MainApp({ currentUser, onLogout, auditAnswers, setAuditAnswers }) {
  const [tab,          setTab]          = useState("board");
  const [issues,       setIssues]       = useState(SEED_ISSUES);
  const [selected,     setSelected]     = useState(null);
  const [filter,       setFilter]       = useState("ALL");
  const [myOnly,       setMyOnly]       = useState(false);
  const [toast,        setToast]        = useState("");
  // raise
  const [desc,         setDesc]         = useState("");
  const [dept,         setDept]         = useState("");
  const [mgr,          setMgr]          = useState("");
  const [scat,         setScat]         = useState("");
  const [img,          setImg]          = useState(null);
  const [genning,      setGenning]      = useState(false);
  const [engineRunning,setEngineRunning]= useState(false);
  const [engineResult, setEngineResult] = useState(null);
  const [engineScore,  setEngineScore]  = useState(null);
  const [engineBand,   setEngineBand]   = useState(null);
  const [engineStd,    setEngineStd]    = useState(null);
  const [descTimer,    setDescTimer]    = useState(null);
  // close
  const [closingId,    setClosingId]    = useState(null);
  const [closeNote,    setCloseNote]    = useState("");
  const [closePhoto,   setClosePhoto]   = useState(null);
  const [closeDocName, setCloseDocName] = useState("");
  // audit
  const [auditDept,    setAuditDept]    = useState(
    currentUser.dept !== "All Departments" && currentUser.dept !== "Executive" && currentUser.dept !== "Finance"
      ? currentUser.dept : ""
  );
  const [auditStep,    setAuditStep]    = useState(0);
  const [localAns,     setLocalAns]     = useState({});

  const imgRef      = useRef();
  const closeImgRef = useRef();
  const closeDocRef = useRef();

  const showToast   = msg => { setToast(msg); setTimeout(() => setToast(""), 2800); };
  const statColor   = s => s==="CLOSED"?C.closed:s==="IN PROGRESS"?C.prog:C.open;
  const statBg      = s => s==="CLOSED"?C.closedBg:s==="IN PROGRESS"?C.progBg:C.openBg;
  const myNCRs      = issues.filter(i => i.manager === currentUser.name);
  const myOpenCt    = myNCRs.filter(i => i.status === "OPEN").length;

  const facilityScores = DEPARTMENTS.map(d => ({ d, sc:deptScore(auditAnswers[d]||{}) }));
  const scoredDepts    = facilityScores.filter(x => x.sc !== null);
  const facilityAvg    = scoredDepts.length === 0 ? null
    : Math.round(scoredDepts.reduce((a,b) => a+b.sc, 0) / scoredDepts.length);
  const myDeptScore    = currentUser.dept && !["Executive","Finance","All Departments"].includes(currentUser.dept)
    ? deptScore(auditAnswers[currentUser.dept]||{}) : null;

  const handleImg = e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = ev => {
      setImg(ev.target.result);
      if (desc.trim().length > 10) runEngine(desc, dept, ev.target.result);
    };
    r.readAsDataURL(f);
  };

  const runEngine = async (d, dp, imgData) => {
    setEngineRunning(true);
    setEngineResult(null); setEngineScore(null); setEngineBand(null); setEngineStd(null);
    const result = await classifyFinding(d, dp, imgData);
    if (result) {
      setEngineResult(result);
      if (result.scat) setScat(prev => prev || result.scat);
      const std = STDS.find(s => s.code === result.primaryStandard) || null;
      setEngineStd(std);
      if (std && std.status === "live" && result.hasGoverningStandard) {
        const repeatCount = issues.filter(i => i.dept===dp && i.scat?.key===result.scat).length;
        const score = computeScore(std, repeatCount, result.visualConditionScore ?? 2);
        setEngineScore(score);
        setEngineBand(getSeverityBand(score));
      }
    }
    setEngineRunning(false);
  };

  const handleDescChange = val => {
    setDesc(val);
    setEngineResult(null); setEngineScore(null); setEngineBand(null); setEngineStd(null);
    if (descTimer) clearTimeout(descTimer);
    if (val.trim().length < 12) return;
    const t = setTimeout(() => runEngine(val, dept, img), 1100);
    setDescTimer(t);
  };

  const handleRaise = async () => {
    if (!desc || !dept || !mgr) { showToast("⚠ Please fill description, department and manager"); return; }
    setGenning(true);
    const m   = USERS.find(u => u.id === mgr);
    const cat = SCATS.find(x => x.key === (scat || engineResult?.scat || "set")) || SCATS[1];
    const now = new Date().toISOString().slice(0,16).replace("T"," ");
    const band = engineBand || SEVERITY_BANDS[0];
    const hasStd = !!(engineResult?.hasGoverningStandard && engineStd?.status === "live");
    const dueDays = engineStd ? Math.round(engineStd.dueDays * band.dueMult) : 14;
    const due = new Date(); due.setDate(due.getDate() + dueDays);
    const dueStr = due.toISOString().slice(0,10);
    let note = await callAI(desc, `${cat.label} (${cat.jp})`, dept, m.name);
    if (!note) note = `Finding recorded under ${cat.label} (${cat.jp}). ${hasStd ? `Standard: ${engineStd.code}.` : "No governing standard — logged as Observation."} Manager ${m.name} notified. Due: ${dueStr}.`;

    const issue = {
      id:`NC-${String(issues.length+1).padStart(3,"0")}`,
      dept, manager:m.name, mgrColor:m.color, mgrInit:m.initials,
      desc, scat:cat, status:"OPEN", photo:img, closeEvidence:null,
      raisedBy:currentUser.name, raisedAt:now,
      aiNote:note, aiClassification:engineResult,
      governingStd:engineStd||null, hasGoverningStandard:hasStd,
      severityScore:engineScore, severityBand:band,
      ncType:hasStd ? band.label : "Observation",
      priority:hasStd ? band.priority : "LOG", dueDate:dueStr,
      timeline:[
        { time:now, actor:currentUser.name, action:"Finding raised"+(img?" · Photo attached":""), type:"raise" },
        { time:now, actor:"AI Engine L2",   action:engineResult ? `Classified: ${engineResult.object} — ${engineResult.condition}` : "Classified", type:"ai" },
        { time:now, actor:"Standards L3",   action:hasStd ? `${engineStd.code} verified (live)` : "No governing standard — Observation only", type:"ai" },
        ...(hasStd ? [{ time:now, actor:"Scoring L4", action:`Score: ${engineScore}/100 → ${band.label} · ${m.name} notified`, type:"ai" }] : []),
      ]
    };
    setIssues(p => [issue, ...p]);
    setGenning(false);
    showToast(`✓ ${issue.id} ${hasStd ? band.label : "Observation"} — ${m.name} notified`);
    setDesc(""); setDept(""); setMgr(""); setScat(""); setImg(null);
    setEngineResult(null); setEngineScore(null); setEngineBand(null); setEngineStd(null);
    setTimeout(() => setTab("board"), 600);
  };

  const updateStatus = (id, status, note, evPhoto, evDoc) => {
    const now = new Date().toISOString().slice(0,16).replace("T"," ");
    const parts = [note||`Status → ${status}`, evPhoto?"· Close-out photo":"", evDoc?`· Doc: ${evDoc}`:""].filter(Boolean);
    const upd = { time:now, actor:currentUser.name, action:parts.join(" "), type:"update" };
    const ce  = status==="CLOSED" ? { note, photo:evPhoto, doc:evDoc } : null;
    setIssues(p => p.map(i => i.id!==id ? i : { ...i, status, closeEvidence:ce, timeline:[...i.timeline,upd] }));
    if (selected?.id===id) setSelected(p => ({ ...p, status, closeEvidence:ce, timeline:[...p.timeline,upd] }));
    setClosingId(null); setCloseNote(""); setClosePhoto(null); setCloseDocName("");
    showToast(`✓ ${id} ${status==="CLOSED" ? "closed out" : "updated"}`);
  };

  const submitAudit = () => {
    setAuditAnswers(prev => ({ ...prev, [auditDept]:{ ...(prev[auditDept]||{}), ...localAns } }));
    showToast(`✓ Audit submitted for ${auditDept}`);
    setTimeout(() => { setLocalAns({}); setAuditStep(0); setTab("report"); }, 800);
  };

  const filtered = (() => {
    let l = myOnly ? myNCRs : issues;
    if (filter !== "ALL") l = l.filter(i => i.status === filter);
    return l;
  })();

  // ── DETAIL VIEW ────────────────────────────────────────
  if (selected) {
    const cat = selected.scat;
    const isMyNCR = selected.manager === currentUser.name;
    return (
      <Shell toast={toast}>
        <div style={{ background:cat.grad }}>
          <div style={{ display:"flex", alignItems:"center", padding:"16px", gap:10 }}>
            <button style={sx.backBtnW} onClick={() => setSelected(null)}>← Back</button>
            <div style={{ marginLeft:"auto", background:"rgba(255,255,255,0.22)", borderRadius:100,
              padding:"3px 14px", fontSize:12, fontWeight:900, color:"#fff", fontFamily:MONO }}>
              {selected.id}
            </div>
            {isMyNCR && <div style={{ background:"rgba(255,255,255,0.22)", borderRadius:100,
              padding:"3px 10px", fontSize:9, fontWeight:800, color:"#fff" }}>MY NCR</div>}
          </div>
          {selected.photo && (
            <div style={{ position:"relative", margin:"0 16px", borderRadius:14, overflow:"hidden" }}>
              <img src={selected.photo} alt="" style={{ width:"100%", height:180, objectFit:"cover" }}/>
              <div style={{ position:"absolute", bottom:8, left:8, background:"rgba(0,0,0,0.6)",
                color:"#fff", fontSize:9, padding:"3px 10px", borderRadius:6 }}>📷 EVIDENCE</div>
            </div>
          )}
          <div style={{ padding:"12px 18px 18px" }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:6,
              background:"rgba(255,255,255,0.22)", borderRadius:100, padding:"3px 12px", marginBottom:8 }}>
              <span>{cat.icon}</span>
              <span style={{ fontSize:11, fontWeight:800, color:"#fff", letterSpacing:1 }}>{cat.label}</span>
            </div>
            <div style={{ fontSize:19, fontWeight:900, color:"#fff", marginBottom:5 }}>{selected.dept}</div>
            <div style={{ fontSize:13, color:"rgba(255,255,255,0.85)", lineHeight:1.6 }}>{selected.desc}</div>
          </div>
        </div>

        {/* Score bar */}
        {selected.severityScore != null && selected.severityBand && (
          <div style={{ margin:"12px 16px 0", background:C.surface,
            border:`1px solid ${selected.severityBand.color}44`, borderRadius:12, padding:"12px 14px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
              <div>
                <div style={{ fontSize:9, color:C.inkLight, letterSpacing:2 }}>L4 COMPLIANCE SCORE</div>
                {selected.governingStd && <div style={{ fontSize:10, color:C.teal, marginTop:2 }}>
                  {selected.governingStd.code} — {selected.governingStd.title}</div>}
              </div>
              <div style={{ fontSize:26, fontWeight:900, color:selected.severityBand.color }}>
                {selected.severityScore}<span style={{ fontSize:11 }}>/100</span>
              </div>
            </div>
            <div style={{ height:5, background:C.border, borderRadius:3, overflow:"hidden" }}>
              <div style={{ height:"100%", width:`${selected.severityScore}%`,
                background:selected.severityBand.color, borderRadius:3 }}/>
            </div>
            <div style={{ marginTop:6, fontSize:10, color:C.inkMid }}>
              {selected.severityBand.label} · Priority: <strong style={{ color:selected.severityBand.color }}>
              {selected.severityBand.priority}</strong> · Due: {selected.dueDate}
            </div>
          </div>
        )}
        {selected.hasGoverningStandard === false && (
          <div style={{ margin:"12px 16px 0", background:`${C.prog}18`,
            border:`1px solid ${C.prog}44`, borderRadius:12, padding:"12px 14px" }}>
            <div style={{ fontSize:10, fontWeight:800, color:C.prog, letterSpacing:1, marginBottom:3 }}>
              OBSERVATION — NO GOVERNING STANDARD
            </div>
            <div style={{ fontSize:11, color:C.inkMid, lineHeight:1.5 }}>
              Logged as Observation only — no score or penalty. Standard proposal queued for review.
            </div>
          </div>
        )}

        {/* Meta grid */}
        <div style={{ padding:"12px 16px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
          {[
            { label:"Manager", val:selected.manager, color:selected.mgrColor },
            { label:"Status",  val:selected.status,  color:statColor(selected.status) },
            { label:"Type",    val:selected.ncType||"NCR", color:selected.severityBand?.color||C.teal },
            { label:"Raised",  val:selected.raisedAt?.slice(0,10), color:C.inkMid },
          ].map(m => (
            <div key={m.label} style={{ background:C.surfaceAlt, borderRadius:10,
              padding:"9px 12px", border:`1px solid ${C.border}` }}>
              <div style={{ fontSize:9, color:C.inkLight, letterSpacing:2, marginBottom:2 }}>{m.label}</div>
              <div style={{ fontSize:12, fontWeight:800, color:m.color }}>{m.val}</div>
            </div>
          ))}
        </div>

        {/* AI note */}
        <div style={{ margin:"0 16px 12px", background:`${C.s5}12`,
          border:`1px solid ${C.s5}44`, borderRadius:12, padding:"12px 14px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
            <span style={{ animation:"spin 8s linear infinite", display:"inline-block" }}>⚙</span>
            <div style={{ fontSize:10, fontWeight:800, color:C.s5, letterSpacing:2 }}>
              5S COMPLIANCE NOTE</div>
            <div style={{ marginLeft:"auto", background:C.s5, color:"#fff",
              fontSize:8, fontWeight:700, padding:"2px 8px", borderRadius:100 }}>AI</div>
          </div>
          <p style={{ fontSize:12, color:C.inkMid, lineHeight:1.75, margin:0 }}>{selected.aiNote}</p>
        </div>

        {/* Timeline */}
        <SHead label="AUDIT TRAIL"/>
        <div style={{ padding:"4px 18px 12px" }}>
          {selected.timeline.map((t,i) => (
            <div key={i} style={{ display:"flex", gap:10, minHeight:48 }}>
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center",
                paddingTop:4, width:14 }}>
                <div style={{ width:11, height:11, borderRadius:"50%", flexShrink:0,
                  background:t.type==="ai"?C.s5:t.type==="raise"?C.open:C.closed,
                  boxShadow:`0 0 0 3px ${t.type==="ai"?C.s5b:t.type==="raise"?C.openBg:C.closedBg}` }}/>
                {i < selected.timeline.length-1 &&
                  <div style={{ flex:1, width:1, background:C.border, margin:"3px 0" }}/>}
              </div>
              <div style={{ flex:1, paddingBottom:10 }}>
                <div style={{ fontSize:12, fontWeight:700, color:C.ink }}>{t.action}</div>
                <div style={{ fontSize:10, color:C.inkLight, marginTop:2, fontFamily:MONO }}>
                  {t.actor} · {t.time}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Close-out */}
        {selected.status !== "CLOSED" && (isMyNCR || currentUser.role==="Admin" || currentUser.role==="Auditor") && (
          <div style={{ padding:"0 16px 32px" }}>
            <SHead label="UPDATE STATUS"/>
            {closingId === selected.id ? (
              <div style={{ background:C.closedBg, border:`1.5px solid ${C.closed}44`,
                borderRadius:14, padding:"14px" }}>
                <div style={{ fontSize:11, fontWeight:800, color:C.closed,
                  letterSpacing:2, marginBottom:12 }}>CLOSE-OUT DETAILS</div>
                <FLabel text="CORRECTIVE ACTION TAKEN"/>
                <textarea style={{ ...sx.textarea, background:C.surface, borderColor:`${C.closed}33` }}
                  rows={3} value={closeNote} onChange={e=>setCloseNote(e.target.value)}
                  placeholder="Describe what was done to resolve this finding…"/>
                <FLabel text="CLOSE-OUT PHOTO"/>
                <div style={{ border:`2px dashed ${closePhoto?C.closed:C.border}`, borderRadius:10,
                  background:closePhoto?C.closedBg:C.surfaceAlt, overflow:"hidden",
                  minHeight:80, display:"flex", alignItems:"center", justifyContent:"center",
                  cursor:"pointer" }} onClick={() => closeImgRef.current.click()}>
                  {closePhoto
                    ? <div style={{ position:"relative", width:"100%" }}>
                        <img src={closePhoto} alt="" style={{ width:"100%",height:120,objectFit:"cover",display:"block" }}/>
                        <div style={{ position:"absolute", top:6, right:6, background:C.closed,
                          color:"#fff", fontSize:9, fontWeight:800, padding:"2px 9px", borderRadius:100 }}>
                          ADDED</div>
                      </div>
                    : <div style={{ textAlign:"center", padding:16 }}>
                        <div style={{ fontSize:24 }}>📷</div>
                        <div style={{ fontSize:11, fontWeight:700, color:C.inkMid, marginTop:6 }}>
                          Tap to add close-out photo</div>
                      </div>
                  }
                  <input ref={closeImgRef} type="file" accept="image/*"
                    style={{ display:"none" }}
                    onChange={e => { const f=e.target.files[0]; if(!f)return;
                      const r=new FileReader(); r.onload=ev=>setClosePhoto(ev.target.result); r.readAsDataURL(f); }}/>
                </div>
                <FLabel text="SUPPORTING DOCUMENT (optional)"/>
                <div style={{ border:`2px dashed ${closeDocName?C.closed:C.border}`, borderRadius:10,
                  background:closeDocName?C.closedBg:C.surfaceAlt, padding:"12px 14px",
                  display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}
                  onClick={() => closeDocRef.current.click()}>
                  <span style={{ fontSize:22 }}>{closeDocName?"📄":"📎"}</span>
                  <div style={{ flex:1 }}>
                    {closeDocName
                      ? <div style={{ fontSize:12, fontWeight:800, color:C.closed }}>{closeDocName}</div>
                      : <><div style={{ fontSize:12, fontWeight:700, color:C.inkMid }}>Attach document</div>
                          <div style={{ fontSize:10, color:C.inkLight }}>PDF, Word, Excel or image</div></>}
                  </div>
                  <input ref={closeDocRef} type="file"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg"
                    style={{ display:"none" }}
                    onChange={e => { const f=e.target.files[0]; if(f) setCloseDocName(f.name); }}/>
                </div>
                <div style={{ display:"flex", gap:8, marginTop:12 }}>
                  <button style={sx.ghostBtn} onClick={() => {
                    setClosingId(null); setClosePhoto(null); setCloseDocName(""); setCloseNote("");
                  }}>Cancel</button>
                  <button style={{ ...sx.solidBtn, background:`linear-gradient(135deg,${C.closed},#34D399)` }}
                    onClick={() => updateStatus(selected.id,"CLOSED",closeNote||"Resolved",closePhoto,closeDocName)}>
                    Submit Close-Out
                  </button>
                </div>
              </div>
            ) : (
              <div style={{ display:"flex", gap:8 }}>
                {selected.status==="OPEN" && (
                  <button style={{ ...sx.solidBtn, background:`linear-gradient(135deg,${C.prog},#FCD34D)` }}
                    onClick={() => updateStatus(selected.id,"IN PROGRESS","Acknowledged")}>
                    Acknowledge
                  </button>
                )}
                <button style={{ ...sx.solidBtn, background:`linear-gradient(135deg,${C.closed},#34D399)` }}
                  onClick={() => setClosingId(selected.id)}>
                  Close Out
                </button>
              </div>
            )}
          </div>
        )}
        {selected.status==="CLOSED" && (
          <div style={{ margin:"0 16px 28px" }}>
            <div style={{ padding:"12px", background:C.closedBg, border:`1px solid ${C.closed}44`,
              borderRadius:10, textAlign:"center", fontSize:12, fontWeight:800,
              color:C.closed, letterSpacing:2, marginBottom:
              selected.closeEvidence?.photo||selected.closeEvidence?.doc?10:0 }}>
              NONCONFORMANCE CLOSED
            </div>
            {selected.closeEvidence && (selected.closeEvidence.note||selected.closeEvidence.photo||selected.closeEvidence.doc) && (
              <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, overflow:"hidden" }}>
                <div style={{ padding:"8px 12px", borderBottom:`1px solid ${C.border}`,
                  fontSize:9, fontWeight:800, color:C.inkLight, letterSpacing:2 }}>
                  CLOSE-OUT EVIDENCE</div>
                {selected.closeEvidence.note && (
                  <div style={{ padding:"8px 12px", borderBottom:`1px solid ${C.border}` }}>
                    <div style={{ fontSize:9, color:C.inkLight, marginBottom:3 }}>CORRECTIVE ACTION</div>
                    <div style={{ fontSize:12, color:C.inkMid }}>{selected.closeEvidence.note}</div>
                  </div>
                )}
                {selected.closeEvidence.photo && (
                  <img src={selected.closeEvidence.photo} alt="" style={{ width:"100%",height:140,objectFit:"cover",display:"block" }}/>
                )}
                {selected.closeEvidence.doc && (
                  <div style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 12px" }}>
                    <span style={{ fontSize:20 }}>📄</span>
                    <div>
                      <div style={{ fontSize:12, fontWeight:800, color:C.ink }}>{selected.closeEvidence.doc}</div>
                      <div style={{ fontSize:10, color:C.inkLight }}>Supporting document</div>
                    </div>
                    <span style={{ marginLeft:"auto", color:C.closed }}>✓</span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </Shell>
    );
  }

  // ── RAISE ──────────────────────────────────────────────
  if (tab === "raise") {
    const engineCat = SCATS.find(c => c.key === (scat||engineResult?.scat)) || null;
    const hasStd = !!(engineResult?.hasGoverningStandard && engineStd?.status==="live");
    const noStd  = engineResult && !engineResult.hasGoverningStandard;
    return (
      <Shell toast={toast}>
        <div style={{ background:`linear-gradient(135deg,${TEAL},${C.tealDk})`,
          padding:"14px 16px 16px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <button style={sx.backBtnW} onClick={() => setTab("board")}>← Back</button>
            <div style={{ fontSize:14, fontWeight:900, color:"#fff", letterSpacing:2 }}>RAISE FINDING</div>
            <div style={{ marginLeft:"auto", fontSize:9, color:"rgba(255,255,255,0.7)", letterSpacing:1 }}>
              L1→L2→L3→L4 ENGINE</div>
          </div>
        </div>
        <div style={{ padding:"14px 16px" }}>

          {/* L1 — Evidence */}
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
            <div style={{ width:20, height:20, borderRadius:5, background:`linear-gradient(135deg,${TEAL},${C.tealDk})`,
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:9, fontWeight:900, color:"#fff" }}>L1</div>
            <div style={{ fontSize:11, fontWeight:800, color:C.ink, letterSpacing:1 }}>EVIDENCE</div>
          </div>
          <div style={{ border:`2px dashed ${img?C.teal:C.border}`, borderRadius:12, minHeight:110,
            display:"flex", alignItems:"center", justifyContent:"center",
            cursor:"pointer", overflow:"hidden", background:C.surfaceAlt, marginBottom:8 }}
            onClick={() => imgRef.current.click()}>
            {img
              ? <img src={img} alt="" style={{ width:"100%",height:150,objectFit:"cover" }}/>
              : <div style={{ textAlign:"center", padding:16 }}>
                  <div style={{ fontSize:30 }}>📷</div>
                  <div style={{ fontSize:12, fontWeight:800, color:C.ink, marginTop:6 }}>
                    Tap to attach photo from library</div>
                  <div style={{ fontSize:10, color:C.inkLight, marginTop:3 }}>
                    Photo is evidence — AI will analyse it</div>
                </div>
            }
            <input ref={imgRef} type="file" accept="image/*"
              style={{ display:"none" }} onChange={handleImg}/>
          </div>
          <textarea style={{ ...sx.textarea, marginBottom:8 }} rows={3} value={desc}
            onChange={e => handleDescChange(e.target.value)}
            placeholder="Describe the finding — e.g. Pallet blocking fire extinguisher…"/>
          <div style={{ display:"flex", gap:8, marginBottom:10 }}>
            <select style={{ ...sx.select, flex:1 }} value={dept}
              onChange={e => { setDept(e.target.value); if(desc.trim().length>10) runEngine(desc,e.target.value,img); }}>
              <option value="">— Department —</option>
              {DEPARTMENTS.map(d => <option key={d}>{d}</option>)}
            </select>
            <select style={{ ...sx.select, flex:1 }} value={mgr}
              onChange={e => setMgr(e.target.value)}>
              <option value="">— Manager —</option>
              {USERS.filter(u => u.role==="Manager"||u.role==="Supervisor").map(m => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </div>

          {/* Engine running */}
          {engineRunning && (
            <div style={{ background:C.surfaceAlt, border:`1px solid ${C.border}`,
              borderRadius:10, padding:"12px 14px", marginBottom:8 }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ animation:"spin 1.2s linear infinite", display:"inline-block", fontSize:18 }}>⚙</span>
                <div>
                  <div style={{ fontSize:12, fontWeight:800, color:C.teal }}>AI ENGINE RUNNING…</div>
                  <div style={{ fontSize:10, color:C.inkLight }}>L2 Classify → L3 Verify → L4 Score</div>
                </div>
              </div>
            </div>
          )}

          {/* Engine results */}
          {engineResult && !engineRunning && (
            <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:10 }}>
              {/* L2 */}
              <div style={{ background:C.surfaceAlt, border:`1px solid ${C.teal}44`,
                borderRadius:10, padding:"10px 12px" }}>
                <div style={{ display:"flex", gap:6, marginBottom:6 }}>
                  <div style={{ background:`linear-gradient(135deg,${TEAL},${C.tealDk})`, color:"#fff",
                    fontSize:8, fontWeight:800, padding:"2px 8px", borderRadius:100 }}>L2 CLASSIFIED</div>
                  <div style={{ marginLeft:"auto", fontSize:9, color:C.inkLight }}>
                    {engineResult.confidence?.toUpperCase()}</div>
                </div>
                <div style={{ display:"flex", gap:12, marginBottom:6 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:9, color:C.inkLight }}>OBJECT</div>
                    <div style={{ fontSize:12, fontWeight:800, color:C.ink }}>{engineResult.object}</div>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:9, color:C.inkLight }}>RISK</div>
                    <div style={{ fontSize:12, fontWeight:800, color:C.ink }}>{engineResult.riskCategory}</div>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:9, color:C.inkLight }}>5S PILLAR</div>
                    <div style={{ fontSize:12, fontWeight:800, color:engineCat?.color||C.teal }}>
                      {engineCat?.short||"—"} {engineCat?.label||""}</div>
                  </div>
                </div>
                <div style={{ padding:"6px 10px", background:`${C.open}14`,
                  border:`1px solid ${C.open}33`, borderRadius:7 }}>
                  <div style={{ fontSize:9, color:C.inkLight, marginBottom:2 }}>IMMEDIATE ACTION</div>
                  <div style={{ fontSize:11, fontWeight:700, color:C.ink }}>{engineResult.immediateAction}</div>
                </div>
              </div>

              {/* L3 */}
              <div style={{ background:C.surfaceAlt,
                border:`1px solid ${hasStd?C.closed+"44":noStd?C.prog+"44":C.border}`,
                borderRadius:10, padding:"10px 12px" }}>
                <div style={{ marginBottom:6 }}>
                  <div style={{ display:"inline-block", background:hasStd?`linear-gradient(135deg,${C.closed},#34D399)`:noStd?`linear-gradient(135deg,${C.prog},#FCD34D)`:C.border,
                    color:"#fff", fontSize:8, fontWeight:800, padding:"2px 8px", borderRadius:100 }}>
                    L3 {hasStd?"STANDARD VERIFIED":noStd?"NO STANDARD":"CHECKING"}
                  </div>
                </div>
                {hasStd ? (
                  <>
                    <div style={{ fontSize:11, fontWeight:800, color:C.closed }}>
                      {engineStd.code} — {engineStd.title}</div>
                    <div style={{ fontSize:10, color:C.inkLight, marginTop:2 }}>
                      {engineStd.type} · {engineStd.scope}</div>
                  </>
                ) : noStd ? (
                  <div>
                    <div style={{ fontSize:11, fontWeight:800, color:C.prog }}>No governing standard found</div>
                    <div style={{ fontSize:10, color:C.inkMid, marginTop:4, lineHeight:1.5 }}>
                      Will be logged as <strong>Observation only</strong> — no score, no penalty.
                      A standard proposal will be queued for review.</div>
                    {engineResult.proposedStandardTitle && (
                      <div style={{ marginTop:8, padding:"6px 10px",
                        background:`${C.prog}18`, borderRadius:7 }}>
                        <div style={{ fontSize:9, color:C.inkLight }}>PROPOSED STANDARD</div>
                        <div style={{ fontSize:11, fontWeight:700, color:C.ink }}>
                          {engineResult.proposedStandardTitle}</div>
                      </div>
                    )}
                  </div>
                ) : null}
              </div>

              {/* L4 */}
              {hasStd && engineScore !== null && engineBand && (
                <div style={{ background:C.surfaceAlt,
                  border:`1px solid ${engineBand.color}44`, borderRadius:10, padding:"10px 12px" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                    <div>
                      <div style={{ display:"inline-block", background:`linear-gradient(135deg,${engineBand.color},${engineBand.color}99)`,
                        color:"#fff", fontSize:8, fontWeight:800, padding:"2px 8px",
                        borderRadius:100, marginBottom:4 }}>L4 SCORED</div>
                      <div style={{ fontSize:16, fontWeight:900, color:engineBand.color }}>
                        {engineBand.label}</div>
                    </div>
                    <div style={{ marginLeft:"auto", fontSize:36, fontWeight:900,
                      color:engineBand.color, lineHeight:1 }}>
                      {engineScore}<span style={{ fontSize:12 }}>/100</span>
                    </div>
                  </div>
                  <div style={{ height:5, background:C.border, borderRadius:3, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${engineScore}%`,
                      background:engineBand.color, borderRadius:3 }}/>
                  </div>
                  <div style={{ display:"flex", justifyContent:"space-between",
                    fontSize:8, color:C.inkLight, marginTop:4 }}>
                    <span>Obs</span><span>Minor</span><span>Moderate</span><span>Major</span><span>Critical</span>
                  </div>
                </div>
              )}

              {/* Category override */}
              <div>
                <div style={{ fontSize:9, color:C.inkLight, letterSpacing:2,
                  fontWeight:800, marginBottom:5 }}>
                  5S CATEGORY <span style={{ color:C.teal }}>(AI selected — tap to override)</span></div>
                <div style={{ display:"flex", gap:5 }}>
                  {SCATS.map(c => (
                    <button key={c.key} onClick={() => setScat(c.key)}
                      style={{ flex:1, display:"flex", flexDirection:"column",
                        alignItems:"center", gap:2, padding:"7px 3px",
                        background:(scat||engineResult?.scat)===c.key?c.grad:C.surfaceAlt,
                        border:`1.5px solid ${(scat||engineResult?.scat)===c.key?c.color:C.border}`,
                        borderRadius:9, cursor:"pointer" }}>
                      <span style={{ fontSize:13, color:(scat||engineResult?.scat)===c.key?"#fff":c.color }}>
                        {c.icon}</span>
                      <span style={{ fontSize:9, fontWeight:800,
                        color:(scat||engineResult?.scat)===c.key?"#fff":c.color }}>{c.short}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Submit */}
          <button style={{
            width:"100%", marginTop:8, padding:"14px", border:"none", borderRadius:11,
            color:engineResult?"#fff":C.inkLight, fontSize:14, fontWeight:800,
            letterSpacing:1, fontFamily:FONT,
            background:engineResult
              ? (hasStd ? `linear-gradient(135deg,${engineBand?.color||TEAL},${engineBand?.color||TEAL}aa)`
                       : `linear-gradient(135deg,${C.prog},#FCD34D)`)
              : C.surfaceAlt,
            cursor:engineResult&&!genning?"pointer":"default",
            opacity:genning?0.65:1,
            display:"flex", alignItems:"center", justifyContent:"center", gap:8
          }} onClick={handleRaise} disabled={!engineResult||genning}>
            {genning
              ? <><span style={{ animation:"spin 1s linear infinite", display:"inline-block" }}>⚙</span> Creating record…</>
              : engineResult
                ? (hasStd ? `Raise ${engineBand?.label||"NCR"} — Notify Manager`
                          : "Log Observation — Queue Standard Proposal")
                : "Describe finding above to activate engine"
            }
          </button>
        </div>
      </Shell>
    );
  }

  // ── AUDIT ──────────────────────────────────────────────
  if (tab === "audit") {
    const cat = SCATS[auditStep];
    const setAns = (k,i,v) => setLocalAns(p => ({ ...p, [`${k}_${i}`]:v }));
    const getAns = (k,i) => localAns[`${k}_${i}`];
    const catPct = catScore({ ...(auditAnswers[auditDept]||{}), ...localAns }, cat.key);
    const labels = ["None","Poor","Partial","Good","Full"];
    return (
      <Shell toast={toast}>
        <div style={{ background:`linear-gradient(135deg,${TEAL},${C.tealDk})`, padding:"14px 16px 16px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
            <button style={sx.backBtnW} onClick={() => setTab("board")}>← Back</button>
            <div style={{ fontSize:14, fontWeight:900, color:"#fff", letterSpacing:2 }}>5S AUDIT</div>
          </div>
          <select style={{ width:"100%", padding:"10px 12px", borderRadius:10,
            border:"1.5px solid rgba(255,255,255,0.3)",
            background:"rgba(255,255,255,0.15)", color:"#fff",
            fontFamily:FONT, fontSize:13, fontWeight:700 }}
            value={auditDept}
            onChange={e => { setAuditDept(e.target.value); setLocalAns({}); setAuditStep(0); }}>
            <option value="" style={{ color:C.ink }}>— Select department to audit —</option>
            {DEPARTMENTS.map(d => <option key={d} value={d} style={{ color:C.ink }}>{d}</option>)}
          </select>
        </div>

        {!auditDept ? (
          <div style={{ textAlign:"center", padding:"48px 20px" }}>
            <div style={{ fontSize:40 }}>📋</div>
            <div style={{ fontSize:13, fontWeight:700, color:C.inkLight, marginTop:10 }}>
              Select a department to begin</div>
          </div>
        ) : (
          <>
            <div style={{ display:"flex", overflowX:"auto", gap:5, padding:"10px 16px",
              borderBottom:`1px solid ${C.border}` }}>
              {SCATS.map((c,i) => {
                const pct = catScore({ ...(auditAnswers[auditDept]||{}), ...localAns }, c.key);
                return (
                  <button key={c.key} onClick={() => setAuditStep(i)}
                    style={{ display:"flex", flexDirection:"column", alignItems:"center",
                      gap:2, padding:"7px 10px", flexShrink:0, minWidth:56,
                      background:i===auditStep?c.grad:C.surface,
                      border:`1.5px solid ${i===auditStep?c.color:C.border}`,
                      borderRadius:9, cursor:"pointer" }}>
                    <span style={{ fontSize:12, color:i===auditStep?"#fff":c.color }}>{c.icon}</span>
                    <span style={{ fontSize:9, fontWeight:800,
                      color:i===auditStep?"#fff":c.color }}>{c.short}</span>
                    {pct!==null && <span style={{ fontSize:9, fontWeight:800,
                      color:i===auditStep?"rgba(255,255,255,0.9)":scoreColor(pct) }}>{pct}%</span>}
                  </button>
                );
              })}
            </div>
            <div style={{ margin:"10px 16px", background:cat.bg,
              border:`1px solid ${cat.color}33`, borderRadius:12,
              padding:"11px 14px", display:"flex", justifyContent:"space-between" }}>
              <div>
                <div style={{ fontSize:13, fontWeight:900, color:cat.color }}>{cat.label}</div>
                <div style={{ fontSize:10, color:C.inkLight }}>{cat.jp} · SOP-linked · 0–4</div>
              </div>
              {catPct!==null && <div style={{ fontSize:22, fontWeight:900, color:scoreColor(catPct) }}>{catPct}%</div>}
            </div>
            <div style={{ padding:"0 16px", display:"flex", flexDirection:"column", gap:9 }}>
              {cat.questions.map((item,qi) => {
                const val = getAns(cat.key, qi);
                return (
                  <div key={qi} style={{ background:C.surface,
                    border:`1.5px solid ${val!==undefined?cat.color+"55":C.border}`,
                    borderRadius:12, padding:"11px 12px" }}>
                    <div style={{ display:"flex", gap:8, alignItems:"flex-start", marginBottom:9 }}>
                      <div style={{ width:20, height:20, borderRadius:5, background:cat.bg,
                        display:"flex", alignItems:"center", justifyContent:"center",
                        fontSize:9, fontWeight:900, color:cat.color, flexShrink:0 }}>{qi+1}</div>
                      <div>
                        <div style={{ fontSize:12, fontWeight:700, color:C.ink, lineHeight:1.5 }}>{item.q}</div>
                        <div style={{ fontSize:9, color:C.inkLight, marginTop:2, fontFamily:MONO }}>{item.ref}</div>
                      </div>
                    </div>
                    <div style={{ display:"flex", gap:4 }}>
                      {[0,1,2,3,4].map(r => (
                        <button key={r} onClick={() => setAns(cat.key, qi, r)}
                          style={{ flex:1, padding:"7px 2px", borderRadius:7, cursor:"pointer",
                            border:`1.5px solid ${val===r?cat.color:C.border}`,
                            background:val===r?cat.grad:"transparent",
                            display:"flex", flexDirection:"column", alignItems:"center", gap:1 }}>
                          <span style={{ fontSize:11, fontWeight:800,
                            color:val===r?"#fff":C.inkMid }}>{r}</span>
                          <span style={{ fontSize:7, color:val===r?"rgba(255,255,255,0.8)":C.inkLight }}>
                            {labels[r]}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ display:"flex", gap:8, padding:"14px 16px" }}>
              {auditStep > 0 && (
                <button style={sx.ghostBtn} onClick={() => setAuditStep(auditStep-1)}>← Prev</button>
              )}
              {auditStep < SCATS.length-1
                ? <button style={{ ...sx.solidBtn, background:cat.grad }}
                    onClick={() => setAuditStep(auditStep+1)}>
                    Next: {SCATS[auditStep+1].label} →
                  </button>
                : <button style={{ ...sx.solidBtn, background:`linear-gradient(135deg,${C.closed},#34D399)` }}
                    onClick={submitAudit}>Submit Audit</button>
              }
            </div>
          </>
        )}
      </Shell>
    );
  }

  // ── REPORT ─────────────────────────────────────────────
  if (tab === "report") {
    return (
      <Shell toast={toast}>
        <div style={{ background:`linear-gradient(135deg,${TEAL},${C.tealDk})`,
          padding:"14px 16px 20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
            <button style={sx.backBtnW} onClick={() => setTab("board")}>← Back</button>
            <div style={{ fontSize:14, fontWeight:900, color:"#fff", letterSpacing:2 }}>MONTHLY REPORT</div>
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <div style={{ flex:1, background:"rgba(255,255,255,0.14)", border:"1px solid rgba(255,255,255,0.22)",
              borderRadius:12, padding:"13px", textAlign:"center" }}>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2, marginBottom:3 }}>FACILITY SCORE</div>
              <div style={{ fontSize:32, fontWeight:900, color:"#fff" }}>
                {facilityAvg !== null ? `${facilityAvg}%` : "—"}</div>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.5)", marginTop:3 }}>
                {scoredDepts.length}/{DEPARTMENTS.length} audited</div>
            </div>
            <div style={{ flex:1, background:"rgba(255,255,255,0.14)", border:"1px solid rgba(255,255,255,0.22)",
              borderRadius:12, padding:"13px", textAlign:"center" }}>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2, marginBottom:3 }}>OPEN NCRs</div>
              <div style={{ fontSize:32, fontWeight:900, color:"#fff" }}>
                {issues.filter(i => i.status==="OPEN").length}</div>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.5)", marginTop:3 }}>require action</div>
            </div>
          </div>
        </div>

        <SHead label="DEPARTMENT SCORES — AUDIT BASED"/>
        {facilityScores.map(({d,sc}) => {
          const col = sc !== null ? scoreColor(sc) : C.inkLight;
          return (
            <div key={d} style={{ display:"flex", alignItems:"center", gap:10,
              padding:"9px 16px", borderBottom:`1px solid ${C.border}` }}>
              <div style={{ fontSize:12, color:sc!==null?C.ink:C.inkLight,
                fontWeight:sc!==null?700:400, width:116, flexShrink:0 }}>{d}</div>
              <div style={{ flex:1, height:7, background:C.border, borderRadius:3, overflow:"hidden" }}>
                {sc!==null && <div style={{ width:`${sc}%`, height:"100%", background:col, borderRadius:3 }}/>}
              </div>
              <div style={{ fontSize:12, fontWeight:800, color:col, width:52, textAlign:"right" }}>
                {sc!==null ? `${sc}%` : "Pending"}</div>
            </div>
          );
        })}

        <SHead label="5S CATEGORY AVERAGES"/>
        {SCATS.map(cat => {
          const scores = scoredDepts.map(({d}) => catScore(auditAnswers[d]||{},cat.key)).filter(v=>v!==null);
          const avg = scores.length===0 ? null : Math.round(scores.reduce((a,b)=>a+b,0)/scores.length);
          return (
            <div key={cat.key} style={{ display:"flex", alignItems:"center", gap:10,
              padding:"9px 16px", borderBottom:`1px solid ${C.border}` }}>
              <div style={{ width:28, height:28, borderRadius:7, background:cat.grad,
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:12, flexShrink:0 }}>
                <span style={{ color:"#fff" }}>{cat.icon}</span>
              </div>
              <div style={{ fontSize:11, fontWeight:700, color:C.ink, width:100, flexShrink:0 }}>{cat.label}</div>
              <div style={{ flex:1, height:7, background:C.border, borderRadius:3, overflow:"hidden" }}>
                {avg!==null && <div style={{ width:`${avg}%`, height:"100%", background:cat.grad, borderRadius:3 }}/>}
              </div>
              <div style={{ fontSize:12, fontWeight:800, width:46, textAlign:"right",
                color:avg!==null?scoreColor(avg):C.inkLight }}>
                {avg!==null ? `${avg}%` : "—"}</div>
            </div>
          );
        })}

        <SHead label="NCR SUMMARY"/>
        <div style={{ display:"flex", gap:8, padding:"0 16px 24px" }}>
          {[["OPEN",C.open,C.openBg],["IN PROGRESS",C.prog,C.progBg],["CLOSED",C.closed,C.closedBg]].map(([st,col,bg]) => (
            <div key={st} style={{ flex:1, background:bg, border:`1px solid ${col}44`,
              borderRadius:12, padding:"13px 8px", textAlign:"center" }}>
              <div style={{ fontSize:26, fontWeight:900, color:col }}>
                {issues.filter(i => i.status===st).length}</div>
              <div style={{ fontSize:8, color:C.inkMid, letterSpacing:1, marginTop:4 }}>{st}</div>
            </div>
          ))}
        </div>
      </Shell>
    );
  }

  // ── PROFILE ────────────────────────────────────────────
  if (tab === "profile") {
    const myAuditData = auditAnswers[currentUser.dept]||{};
    const allEvents = issues.flatMap(nc => nc.timeline.map(t => ({
      ncId:nc.id, dept:nc.dept, manager:nc.manager, scatColor:nc.scat.color,
      desc:nc.desc.slice(0,55)+(nc.desc.length>55?"…":""), status:nc.status, ...t
    }))).sort((a,b) => b.time.localeCompare(a.time));

    return (
      <Shell toast={toast}>
        <div style={{ background:`linear-gradient(135deg,${currentUser.color}CC,${currentUser.color}88)`,
          padding:"18px 16px 20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
            <button style={{ ...sx.backBtnW }} onClick={() => setTab("board")}>⊞ Home</button>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>MY PROFILE</div>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:14 }}>
            <Av txt={currentUser.initials} color="#fff" size={52}/>
            <div>
              <div style={{ fontSize:18, fontWeight:900, color:"#fff" }}>{currentUser.name}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.7)", marginTop:3 }}>{currentUser.title}</div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.45)", marginTop:2 }}>{currentUser.dept}</div>
            </div>
          </div>
          {myDeptScore !== null && (
            <div style={{ background:"rgba(255,255,255,0.12)", border:"1px solid rgba(255,255,255,0.2)",
              borderRadius:12, padding:"12px 14px", display:"flex",
              justifyContent:"space-between", alignItems:"center" }}>
              <div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>MY DEPT SCORE</div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.45)", marginTop:2 }}>{currentUser.dept}</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:28, fontWeight:900, color:"#fff" }}>{myDeptScore}%</div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>
                  {scoreLabel(myDeptScore)}</div>
              </div>
            </div>
          )}
        </div>

        {/* NCR counts */}
        <div style={{ padding:"12px 16px 0", display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
          {[["OPEN",C.open],["IN PROGRESS",C.prog],["CLOSED",C.closed]].map(([st,col]) => (
            <div key={st} style={{ background:C.surface, border:`1px solid ${C.border}`,
              borderRadius:10, padding:"10px 6px", textAlign:"center" }}>
              <div style={{ fontSize:22, fontWeight:900, color:col }}>
                {myNCRs.filter(n => n.status===st).length}</div>
              <div style={{ fontSize:7, color:C.inkLight, letterSpacing:1, marginTop:3 }}>{st}</div>
            </div>
          ))}
        </div>

        <SHead label={`MY NCRs — ${myNCRs.length} total`}/>
        {myNCRs.length === 0 ? (
          <div style={{ margin:"0 16px", background:C.surface, border:`1px solid ${C.border}`,
            borderRadius:10, padding:"20px", textAlign:"center", color:C.inkLight, fontSize:13 }}>
            <div style={{ fontSize:28, marginBottom:6 }}>✓</div>No NCRs assigned to you
          </div>
        ) : (
          <div style={{ padding:"0 16px", display:"flex", flexDirection:"column", gap:8 }}>
            {myNCRs.map(nc => {
              const days = Math.floor((Date.now()-new Date(nc.raisedAt).getTime())/(864e5));
              const overdue = nc.status!=="CLOSED" && days >= 2;
              return (
                <button key={nc.id} style={{ width:"100%", background:C.surface,
                  border:`1.5px solid ${overdue?`${C.open}88`:C.border}`,
                  borderRadius:12, padding:0, cursor:"pointer", textAlign:"left",
                  overflow:"hidden", fontFamily:FONT, display:"block" }}
                  onClick={() => setSelected(nc)}>
                  <div style={{ height:3, background:nc.scat.grad }}/>
                  <div style={{ padding:"11px 13px" }}>
                    <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:7 }}>
                      <div style={{ background:statBg(nc.status), color:statColor(nc.status),
                        fontSize:9, fontWeight:800, padding:"2px 8px", borderRadius:100 }}>{nc.status}</div>
                      {overdue && <div style={{ background:C.openBg, color:C.open,
                        fontSize:8, fontWeight:800, padding:"2px 7px", borderRadius:100 }}>OVERDUE</div>}
                      <div style={{ marginLeft:"auto", fontSize:10, color:C.inkLight, fontFamily:MONO }}>{nc.id}</div>
                    </div>
                    <div style={{ fontSize:13, fontWeight:800, color:C.ink, marginBottom:3 }}>{nc.dept}</div>
                    <div style={{ fontSize:11, color:C.inkMid, lineHeight:1.5 }}>{nc.desc}</div>
                    <div style={{ fontSize:10, color:overdue?C.open:C.inkLight, marginTop:5, fontWeight:overdue?800:400 }}>
                      {nc.status==="CLOSED" ? "✓ Closed" : `Raised ${days}d ago`}
                      {nc.dueDate && nc.status!=="CLOSED" && ` · Due ${nc.dueDate}`}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {myDeptScore !== null && (
          <>
            <SHead label="MY DEPT — 5S BREAKDOWN"/>
            {SCATS.map(cat => {
              const pct = catScore(myAuditData, cat.key);
              return (
                <div key={cat.key} style={{ display:"flex", alignItems:"center", gap:10,
                  padding:"8px 16px", borderBottom:`1px solid ${C.border}` }}>
                  <div style={{ width:26, height:26, borderRadius:6, background:cat.grad,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:11, flexShrink:0 }}>
                    <span style={{ color:"#fff" }}>{cat.icon}</span>
                  </div>
                  <div style={{ fontSize:11, fontWeight:700, color:C.ink, width:96, flexShrink:0 }}>{cat.label}</div>
                  <div style={{ flex:1, height:6, background:C.border, borderRadius:3, overflow:"hidden" }}>
                    {pct!==null && <div style={{ width:`${pct}%`, height:"100%", background:cat.grad, borderRadius:3 }}/>}
                  </div>
                  <div style={{ fontSize:11, fontWeight:800, width:38, textAlign:"right",
                    color:pct!==null?scoreColor(pct):C.inkLight }}>
                    {pct!==null ? `${pct}%` : "—"}</div>
                </div>
              );
            })}
          </>
        )}

        <SHead label="AUDIT ACTIVITY LOG"/>
        <div style={{ padding:"0 16px 8px" }}>
          {allEvents.slice(0,25).map((ev,i) => {
            const dotColor = ev.type==="ai"?C.s5:ev.type==="raise"?C.open:C.closed;
            const badge = ev.type==="raise"?"RAISED":ev.type==="ai"?"AI":
              ev.action.toLowerCase().includes("closed")?"CLOSED":"UPDATED";
            const badgeColor = badge==="RAISED"?C.open:badge==="AI"?C.s5:badge==="CLOSED"?C.closed:C.prog;
            return (
              <div key={i} style={{ display:"flex", gap:10, minHeight:50 }}>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center",
                  paddingTop:5, width:14, flexShrink:0 }}>
                  <div style={{ width:9, height:9, borderRadius:"50%", background:dotColor,
                    boxShadow:`0 0 0 2px ${dotColor}33` }}/>
                  {i < Math.min(allEvents.length,25)-1 &&
                    <div style={{ flex:1, width:1, background:C.border, margin:"3px 0" }}/>}
                </div>
                <div style={{ flex:1, paddingBottom:10 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:2 }}>
                    <div style={{ fontSize:8, fontWeight:800, color:badgeColor,
                      background:`${badgeColor}18`, padding:"1px 7px", borderRadius:100 }}>{badge}</div>
                    <div style={{ fontSize:9, color:C.inkLight, fontFamily:MONO }}>{ev.ncId}</div>
                    <div style={{ fontSize:9, fontWeight:700, color:C.inkMid }}>{ev.dept}</div>
                    <div style={{ marginLeft:"auto", fontSize:8, color:C.inkLight }}>{ev.time.slice(5)}</div>
                  </div>
                  <div style={{ fontSize:11, color:C.ink, lineHeight:1.4 }}>{ev.action}</div>
                  <div style={{ fontSize:10, color:C.inkLight }}>{ev.actor}</div>
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ padding:"16px" }}>
          <button style={{ width:"100%", padding:"12px", background:C.surfaceAlt,
            border:`1px solid ${C.border}`, borderRadius:10, color:C.inkMid,
            fontSize:13, fontWeight:700, fontFamily:FONT, cursor:"pointer" }}
            onClick={onLogout}>Sign Out</button>
        </div>
      </Shell>
    );
  }

  // ── BOARD ──────────────────────────────────────────────
  const openCt   = issues.filter(i => i.status==="OPEN").length;
  const progCt   = issues.filter(i => i.status==="IN PROGRESS").length;
  const closedCt = issues.filter(i => i.status==="CLOSED").length;

  return (
    <Shell toast={toast}>
      {/* Header */}
      <div style={{ background:`linear-gradient(160deg,${TEAL} 0%,${C.tealDk} 100%)`,
        padding:"20px 16px 18px", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:-30, right:-30, width:120, height:120,
          borderRadius:"50%", background:"rgba(255,255,255,0.07)", pointerEvents:"none" }}/>
        <div style={{ position:"relative" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:38, height:38, borderRadius:10,
                background:"rgba(255,255,255,0.18)", border:"1.5px solid rgba(255,255,255,0.3)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:13, fontWeight:900, color:"#fff", fontFamily:MONO }}>5S</div>
              <div>
                <div style={{ fontSize:16, fontWeight:900, color:"#fff", letterSpacing:1 }}>
                  Gibson Audit</div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>
                  HOUSEKEEPING · MAY 2026</div>
              </div>
            </div>
            <button onClick={() => setTab("profile")}
              style={{ display:"flex", alignItems:"center", gap:7,
                background:"rgba(255,255,255,0.15)", border:"1.5px solid rgba(255,255,255,0.25)",
                borderRadius:20, padding:"5px 12px 5px 6px", cursor:"pointer" }}>
              <Av txt={currentUser.initials} color="#fff" size={24}/>
              <span style={{ fontSize:11, fontWeight:800, color:"#fff" }}>
                {currentUser.name.split(" ")[0]}</span>
              {myOpenCt > 0 && (
                <div style={{ background:C.open, color:"#fff", fontSize:8, fontWeight:900,
                  width:16, height:16, borderRadius:"50%",
                  display:"flex", alignItems:"center", justifyContent:"center" }}>{myOpenCt}</div>
              )}
            </button>
          </div>
          {/* Facility + my dept */}
          <div style={{ display:"flex", gap:8 }}>
            <div style={{ flex:1, background:"rgba(255,255,255,0.12)",
              border:"1px solid rgba(255,255,255,0.18)", borderRadius:10, padding:"9px 12px" }}>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>FACILITY</div>
              <div style={{ fontSize:20, fontWeight:900, color:"#fff" }}>
                {facilityAvg !== null ? `${facilityAvg}%` : "—"}</div>
              <div style={{ fontSize:8, color:"rgba(255,255,255,0.5)" }}>
                {scoredDepts.length}/{DEPARTMENTS.length} depts audited</div>
            </div>
            {myDeptScore !== null && (
              <div style={{ flex:1, background:"rgba(255,255,255,0.12)",
                border:"1px solid rgba(255,255,255,0.18)", borderRadius:10, padding:"9px 12px" }}>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.6)", letterSpacing:2 }}>MY DEPT</div>
                <div style={{ fontSize:20, fontWeight:900, color:"#fff" }}>{myDeptScore}%</div>
                <div style={{ fontSize:8, color:"rgba(255,255,255,0.5)" }}>{currentUser.dept}</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* My open NCR alert */}
      {myOpenCt > 0 && (
        <div style={{ margin:"12px 16px 0", background:C.openBg,
          border:`1px solid ${C.open}44`, borderRadius:12, padding:"11px 14px",
          display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}
          onClick={() => { setMyOnly(true); setFilter("OPEN"); }}>
          <div style={{ width:34, height:34, borderRadius:9, background:C.open,
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>⚠</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:800, color:C.open }}>
              You have {myOpenCt} open NCR{myOpenCt>1?"s":""}</div>
            <div style={{ fontSize:11, color:C.inkMid, marginTop:2 }}>
              Tap to view your outstanding actions</div>
          </div>
          <span style={{ color:C.open, fontSize:16 }}>→</span>
        </div>
      )}

      {/* Raise CTA */}
      <div style={{ padding:"12px 16px 0" }}>
        <button style={{ width:"100%", background:`linear-gradient(135deg,${C.open},#F87171)`,
          border:"none", borderRadius:14, padding:"14px 16px",
          display:"flex", alignItems:"center", gap:12, cursor:"pointer",
          boxShadow:`0 6px 24px ${C.open}33`, textAlign:"left" }}
          onClick={() => setTab("raise")}>
          <div style={{ width:40, height:40, borderRadius:10, background:"rgba(255,255,255,0.2)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>⚠</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:14, fontWeight:900, color:"#fff", letterSpacing:1, fontFamily:FONT }}>
              RAISE NONCONFORMANCE</div>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.8)", marginTop:2 }}>
              AI Standards Verification Engine · L1→L2→L3→L4</div>
          </div>
          <span style={{ fontSize:18, color:"rgba(255,255,255,0.8)" }}>→</span>
        </button>
      </div>

      {/* Stats */}
      <div style={{ display:"flex", gap:8, padding:"10px 16px 0" }}>
        {[
          { label:"OPEN",        val:openCt,   col:C.open,   bg:C.openBg,   f:"OPEN"        },
          { label:"IN PROGRESS", val:progCt,   col:C.prog,   bg:C.progBg,   f:"IN PROGRESS" },
          { label:"CLOSED",      val:closedCt, col:C.closed, bg:C.closedBg, f:"CLOSED"      },
        ].map(st => (
          <button key={st.label} onClick={() => { setFilter(filter===st.f?"ALL":st.f); setMyOnly(false); }}
            style={{ flex:1, background:st.bg,
              border:`1.5px solid ${filter===st.f&&!myOnly?st.col:C.border}`,
              borderRadius:12, padding:"11px 8px", textAlign:"center", cursor:"pointer" }}>
            <div style={{ fontSize:24, fontWeight:900, color:st.col }}>{st.val}</div>
            <div style={{ fontSize:8, color:C.inkMid, letterSpacing:1, marginTop:3 }}>{st.label}</div>
          </button>
        ))}
      </div>

      {/* Filter tabs */}
      <div style={{ display:"flex", padding:"10px 16px 0", gap:4,
        borderBottom:`1px solid ${C.border}`, alignItems:"center" }}>
        <button onClick={() => { setMyOnly(!myOnly); setFilter("ALL"); }}
          style={{ display:"flex", alignItems:"center", gap:5, padding:"5px 10px",
            borderRadius:100, border:`1.5px solid ${myOnly?currentUser.color:C.border}`,
            background:myOnly?`${currentUser.color}18`:"transparent",
            cursor:"pointer", fontSize:9, fontWeight:800,
            color:myOnly?currentUser.color:C.inkLight, flexShrink:0 }}>
          <Av txt={currentUser.initials} color={currentUser.color} size={14}/>
          MINE {myOpenCt>0 && (
            <span style={{ background:C.open, color:"#fff", borderRadius:"50%",
              width:13, height:13, display:"inline-flex",
              alignItems:"center", justifyContent:"center", fontSize:8 }}>{myOpenCt}</span>
          )}
        </button>
        {["ALL","OPEN","IN PROGRESS","CLOSED"].map(f => (
          <button key={f} onClick={() => { setFilter(f); setMyOnly(false); }}
            style={{ flex:1, background:"none", border:"none",
              borderBottom:`2.5px solid ${filter===f&&!myOnly?C.teal:"transparent"}`,
              color:filter===f&&!myOnly?C.teal:C.inkLight,
              fontSize:8, fontWeight:800, letterSpacing:0.5,
              padding:"6px 1px 9px", cursor:"pointer", fontFamily:FONT }}>
            {f}
          </button>
        ))}
      </div>

      {/* Issue cards */}
      <div style={{ padding:"10px 16px", display:"flex", flexDirection:"column", gap:10 }}>
        {filtered.map((nc,idx) => {
          const isMyNCR = nc.manager === currentUser.name;
          const band = nc.severityBand;
          return (
            <div key={nc.id} className="card" style={{ animationDelay:`${idx*0.07}s` }}>
              <button style={{ width:"100%", background:C.surface,
                border:`1.5px solid ${isMyNCR&&nc.status==="OPEN"?`${C.open}66`:C.border}`,
                borderRadius:14, padding:0, cursor:"pointer", textAlign:"left",
                overflow:"hidden", fontFamily:FONT, display:"block",
                boxShadow:isMyNCR&&nc.status==="OPEN"?`0 2px 16px ${C.open}22`:C.shadow }}
                onClick={() => setSelected(nc)}>
                <div style={{ height:4, background:nc.scat.grad }}/>
                <div style={{ padding:"12px 14px" }}>
                  <div style={{ display:"flex", gap:5, alignItems:"center", marginBottom:9, flexWrap:"wrap" }}>
                    <div style={{ background:nc.scat.bg, color:nc.scat.color,
                      fontSize:10, fontWeight:800, padding:"2px 9px", borderRadius:100 }}>
                      {nc.scat.icon} {nc.scat.short}</div>
                    {band ? (
                      <div style={{ background:`${band.color}20`, color:band.color,
                        fontSize:9, fontWeight:800, padding:"2px 8px", borderRadius:100 }}>
                        {nc.severityScore}/100 · {band.label}</div>
                    ) : nc.hasGoverningStandard===false ? (
                      <div style={{ background:`${C.prog}20`, color:C.prog,
                        fontSize:9, fontWeight:800, padding:"2px 8px", borderRadius:100 }}>OBSERVATION</div>
                    ) : null}
                    <div style={{ background:nc.status==="CLOSED"?C.closedBg:nc.status==="IN PROGRESS"?C.progBg:C.openBg,
                      color:statColor(nc.status), fontSize:9, fontWeight:800,
                      padding:"2px 8px", borderRadius:100 }}>{nc.status}</div>
                    {isMyNCR && <div style={{ background:`${currentUser.color}18`,
                      color:currentUser.color, fontSize:8, fontWeight:800,
                      padding:"2px 7px", borderRadius:100 }}>MINE</div>}
                    <div style={{ marginLeft:"auto", fontSize:10, color:C.inkLight, fontFamily:MONO }}>
                      {nc.id}</div>
                  </div>
                  <div style={{ fontSize:13, fontWeight:800, color:C.ink, marginBottom:4 }}>{nc.dept}</div>
                  <div style={{ fontSize:12, color:C.inkMid, lineHeight:1.55, marginBottom:10 }}>{nc.desc}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                      <Av txt={nc.mgrInit} color={nc.mgrColor} size={22}/>
                      <span style={{ fontSize:11, color:C.inkMid }}>{nc.manager}</span>
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:3 }}>
                      {nc.timeline.map((t,i) => (
                        <div key={i} style={{ width:7, height:7, borderRadius:"50%",
                          background:t.type==="ai"?C.s5:t.type==="raise"?C.open:C.closed }}/>
                      ))}
                      <span style={{ fontSize:9, color:C.inkLight, marginLeft:3 }}>{nc.timeline.length}</span>
                    </div>
                  </div>
                </div>
              </button>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign:"center", padding:"48px 20px" }}>
          <div style={{ fontSize:44 }}>{myOnly?"✓":"📋"}</div>
          <div style={{ fontSize:13, fontWeight:700, color:C.inkLight, marginTop:8 }}>
            {myOnly ? "No outstanding NCRs assigned to you" : "No issues found"}</div>
        </div>
      )}

      {/* Bottom nav */}
      <div style={{ position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
        width:"100%", maxWidth:480, background:C.surface,
        borderTop:`1px solid ${C.border}`, display:"flex",
        paddingBottom:"env(safe-area-inset-bottom,0)",
        boxShadow:"0 -4px 24px rgba(0,0,0,0.4)" }}>
        {[
          { id:"board",   icon:"⊞", label:"BOARD"  },
          { id:"raise",   icon:"⚠", label:"RAISE"  },
          { id:"audit",   icon:"📋", label:"AUDIT"  },
          { id:"report",  icon:"◈", label:"REPORT" },
          { id:"profile", icon:"👤", label:"ME"     },
        ].map(n => (
          <button key={n.id}
            style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center",
              gap:2, padding:"11px 2px", background:"none", border:"none",
              color:tab===n.id?C.teal:C.inkLight, fontSize:8, letterSpacing:1,
              fontWeight:800, cursor:"pointer", fontFamily:FONT,
              borderTop:`2.5px solid ${tab===n.id?C.teal:"transparent"}`,
              position:"relative" }}
            onClick={() => setTab(n.id)}>
            <span style={{ fontSize:18 }}>{n.icon}</span>
            {n.label}
            {n.id==="profile" && myOpenCt > 0 && (
              <div style={{ position:"absolute", top:6, right:"calc(50% - 18px)",
                background:C.open, color:"#fff", fontSize:7, fontWeight:900,
                width:14, height:14, borderRadius:"50%",
                display:"flex", alignItems:"center", justifyContent:"center" }}>
                {myOpenCt}
              </div>
            )}
          </button>
        ))}
      </div>
    </Shell>
  );
}

// ─────────────────────────────────────────────────────────
// ROOT — defined last so all components above are ready
// ─────────────────────────────────────────────────────────
export default function App() {
  useEffect(() => injectStyles(), []);
  const [currentUser,  setCurrentUser]  = useState(null);
  const [auditAnswers, setAuditAnswers] = useState(SEED_AUDITS);
  if (!currentUser) return <LoginScreen onLogin={setCurrentUser}/>;
  return (
    <MainApp
      currentUser={currentUser}
      onLogout={() => setCurrentUser(null)}
      auditAnswers={auditAnswers}
      setAuditAnswers={setAuditAnswers}
    />
  );
}
